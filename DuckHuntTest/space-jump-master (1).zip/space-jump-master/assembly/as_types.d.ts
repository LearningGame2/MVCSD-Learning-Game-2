/// <reference types="near-sdk-as/assembly/as_types" />
