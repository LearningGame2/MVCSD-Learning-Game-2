module.exports = require('near-sdk-as/imports')
