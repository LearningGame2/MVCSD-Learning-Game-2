add collectible items (that give extra score)
add slow motion power up
add "usable" rocket power up
add solid blocks power "down"
