# Space Jump

This game was developed in order to participate on the js13kgames 2021 competition.

You can check the game [here](https://thiagorb.github.io/space-jump/).

In the game you control an astronaut, and your goal is to survive as long as possible, by jumping through the platforms.
