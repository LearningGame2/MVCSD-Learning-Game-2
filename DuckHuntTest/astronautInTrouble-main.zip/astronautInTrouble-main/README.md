﻿# Astronaut in Trouble

<img align="right" src="raw.githubusercontent.com/dougkusanagi/astronautInTrouble/main/Prancheta1.png">

<p align="left"> 
    <h3>Controls:</h3><br>
    <strong>Start the Game:</strong> Enter or touch in mobile<br>
    <strong>Jump:</strong> Space bar or touch in mobile<br>
    <strong>Full Screen:</strong> F11 or touch Left top icon
</p>
